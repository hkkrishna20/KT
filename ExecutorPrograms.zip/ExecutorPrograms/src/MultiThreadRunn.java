import java.util.List;



public class MultiThreadRunn implements Runnable {
 
    private final List<Runnable> runnables;
 
    public MultiThreadRunn(List<Runnable> runnables) {
        this.runnables = runnables;
    }
 
    @Override
    public void run() {
        for (Runnable runnable : runnables) {
             new Thread(runnable).start();
        }
    }
}

